<section class="menu-area active" style="    background-color: #222232b8;">
    <div class="top-menu-area">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="menu-full-width">
                        <div class="logo-box">
                            <div class="site-open">
                                <span class="open__only"></span>
                                <span class="open__only"></span>
                                <span class="open__only"></span>
                            </div><!-- end site-open -->
                            <div class="logo">
                                <a href="index.php" title="Avivon"><img src="assets/logo2.png" style="max-height:43px;" alt="logo"></a>
                            </div><!-- end logo -->
                        </div><!-- end logo-box -->
                        <div class="main-menu">
                            <nav class="menu__wrapper">
                                <ul class="dropdown-main">
                                    <li>
                                        <a href="index.php">home</a>
                                    </li>
                                    <!--<li>
                                        <a href="services.php">services</a>
                                    </li>
                                    <li>
                                        <a href="mission.php">mission</a>
                                       
                                    </li>-->
                                    <li>
                                        <a href="about-us.php">about</a>
                                        <!--<div class="main__dropdown-menu">
                                            <ul>
                                                <li><a href="cases1.html">cases 01</a></li>
                                                <li><a href="cases2.html">cases 02</a></li>
                                                <li><a href="single-cases.html">single case</a></li>
                                            </ul>
                                        </div> --><!-- end main__dropdown-menu -->
                                    </li>
                                    <li>
                                        <a href="forex.php">forex</a>
                                    </li>
                                    <li>
                                        <a href="analytics.php">analytics</a>
                                    </li>
                                    <li>
                                        <a href="faq.php">faq</a>
                                    </li>
                                    <li>
                                        <a href="contact.php">contact</a>
                                    </li>
                                    <li>
                                        <a href="/Login">login</a>
                                    </li>
                                </ul>
                            </nav><!-- end menu__wrapper -->
                            <div class="logo-right-button">
                               
                                <div class="contact-para">
                                    <p>+381 12 532299</p>
                                    <span class="fontello icon-phone-call phone-call"></span>
                                </div><!-- end contact-para -->
                            </div><!-- end logo-right-button -->
                        </div><!-- end main-menu -->
                    </div><!-- end menu-full-width -->
                </div><!-- end col-md-12 -->
            </div><!-- end row -->
        </div><!-- end container -->
    </div><!-- end top-menu-area -->
</section><!-- end menu-area --> 