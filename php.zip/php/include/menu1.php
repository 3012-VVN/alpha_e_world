<ul class="off__menu">
        <li class="menu__title-only"><a href="index.php">home</a></li>
       <!-- <li>
                                        <a href="services.php">services</a>
                                    </li>
                                    <li>
                                        <a href="mission.php">mission</a>
                                       
                                    </li>-->
                                    <li>
                                        <a href="about-us.php">about</a>
                                        <!--<div class="main__dropdown-menu">
                                            <ul>
                                                <li><a href="cases1.html">cases 01</a></li>
                                                <li><a href="cases2.html">cases 02</a></li>
                                                <li><a href="single-cases.html">single case</a></li>
                                            </ul>
                                        </div> --><!-- end main__dropdown-menu -->
                                    </li>
                                    <li>
                                        <a href="forex.php">forex</a>
                                    </li>
                                    <li>
                                        <a href="analytics.php">analytics</a>
                                    </li>
                                    <li>
                                        <a href="faq.php">faq</a>
                                    </li>
                                    <li>
                                        <a href="contact.php">contact</a>
                                    </li>
                                    <li>
                                        <a href="/Login">login</a>
                                    </li>
    </ul>