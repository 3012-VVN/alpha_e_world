<footer class="footer footer-black  footer-white ">
        <div class="container-fluid">
          <div class="row">
            <nav class="footer-nav">
              <ul>
                <li>
                  <a href="#" target="_blank">Terms & Condition</a>
                </li>
                <li>
                  <a href="#" target="_blank">Privarcy Policy</a>
                </li>
              </ul>
            </nav>
            <div class="credits ml-auto">
              <span class="copyright">
                ©2019, FX Zone International
              </span>
            </div>
          </div>
        </div>
      </footer>