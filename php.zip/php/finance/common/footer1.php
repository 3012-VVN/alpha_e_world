<footer class="footer footer-black  footer-white ">
        <div class="container-fluid">
          <div class="row">
            <nav class="footer-nav">
              <ul>
                <li>
                  <a href="/TermsCondition" target="_blank" style="font-size:11px">Terms & Condition</a>
                </li>
                <li>
                <p style="font-size:11px; color:#fff;" >Processing Fee @ 5% will be applicable per transaction</p>
                </li>
              </ul>
            </nav>
            <div class="credits ml-auto">
              <span class="copyright" >
                ©2019, Alpha Exchange World
              </span>
            </div>
          </div>
        </div>
      </footer>