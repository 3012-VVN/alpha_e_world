<div class="row">
    <div class="col-md-12">
        <div class="card card-user">
            <div class="card-header">
                <h5 class="card-title">Awaiting Admin Approval</h5>
            </div>
            <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card-header">
                            <h6>Welcome, verification is in process...</h6>
                                <p>If provided details are proper, your account will be activated within 24 hours<br>
                                    For more details contact<br>
                                    Email: support@alphaeworld.com<br>
                                    Contact: +381 12 532299
                            </p>
                            </div>
                        </div>
                    </div>
            </div>
        </div>
    </div>
</div>

