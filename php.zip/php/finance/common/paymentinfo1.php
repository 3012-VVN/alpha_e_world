<div class="row">
    <div class="col-md-12">
        <div class="card card-user">
            <div class="card-header">

                <button type="submit" class="btn blue changePlan1" style="margin-bottom: 10px;">
                    << Change Plan</button> <h5 class="card-title">Payment Options</h5>
            </div>
            <div class="card-body">
                <form method="POST" action="/SubmitPaymentDetail1" enctype="multipart/form-data">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card-header">
                                <h6 class="card-title">Bank details</h6>
                                
                                <p>Please update your payment details by uploading the payment receipt.</p>
                                
                                <h7 style="font-weight: bold;">Bank Details</h7>
                                <p>Bank Name: <span style="font-weight: bold;">SOCIETE GENERALE BANKA SRBIJA AD</span><br>
                                    Account no. <span style="font-weight: bold;">275002022316677422</span><br>
                                    Swift Code: <span style="font-weight: bold;">SOGYRSBG</span><br>
                                    Branch: <span style="font-weight: bold;">Požarevac</span>
                            </p>
                            
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="card-header">
                                <h6 class="card-title">Bank Transfer Details</h6>
</div></div></div>

                    <div class="row">
                        <div class="col-md-5 pr-1">
                            <div class="form-group">
                                <label>Transaction Deatils</label>
                                <input type="text" class="form-control" placeholder="Transaction Deatils" name='tdetails'>
                            </div>
                        </div>
                        <div class="col-md-3 px-1">
                            <div class="form-group">
                                <label>Transaction date</label>
                                <input type="date" class="form-control" placeholder="Date" name="tdate">
                            </div>
                        </div>
                   
                    </div>

                    <div class="row">
                        <div class="col-md-5 pr-1">
                        <label>OR </label>
                        <label style="    color: black;">Upload Bank Recipt / Transaction Screenshot</label>
                        </div>
                   
                   </div>

                   <div class="row">
                        <div class="col-md-5 pr-1">
                            <div class="form-group">
                                <label style='color: orange;'>Add files...</label>
                                <input type="file" class="form-control" placeholder="Transaction Deatils" name='recipt'>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="update ml-auto mr-auto">
                            <button type="submit" class="btn btn-primary btn-round">Update</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

